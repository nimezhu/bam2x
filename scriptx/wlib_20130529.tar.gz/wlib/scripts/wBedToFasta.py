#!/usr/bin/python
#Last-modified: 28 Jan 2013 05:44:20 PM

""" Module/Scripts Description

Copyright (c) 2008 Yunfei Wang <tszn1984@gmail.com>

This code is free software; you can redistribute it and/or modify it
under the terms of the BSD License (see the file COPYING included with
the distribution).

@status:  experimental
@version: 1.0.0
@author:  Yunfei Wang
@contact: tszn1984@gmail.com
"""

# ------------------------------------
# python modules
# ------------------------------------

import os,sys
import string
import argparse
from wLib.wBed import IO,Utils,FastaFile

# ------------------------------------
# constants
# ------------------------------------

def argParser():
    ''' Parse arguments. '''
    p=argparse.ArgumentParser(description='Retrived sequence from genome file.',epilog='dependency wbed')
    p._optionals.title = "Options"
    p.add_argument("-i","--input",dest='fname',type=str,metavar="Input",required=True,help="Either .bed or .tab file.")
    #p.add_argument("-s","--strand",dest="strand",type=str, metavar="strand",default=".",choices=".+-=",help=".: take the strand as indicated in input file. +: take the plus strand of the genome. -: take the minus sequence of the genome. =: take both strands.")
    p.add_argument("-g","--genome",dest="genome",type=str,metavar="genome",default=os.path.expanduser('~')+"/Data/hg19/hg19.fa",help="Genome Fasta file. Default is ~/Data/hg19/hg19.fa.")
    p.add_argument("-c","--case",dest="case",type=str,choices=['o', 'u','l'],default="o",help="o: original, u: uppercase(default), l: lowercase")
    p.add_argument("-l","--linelen",dest='linelength',type=int,metavar='linelength',default=80,help="Bases each line. Default is 80. 0 for unlimited length.")
    if len(sys.argv)==1:
        sys.exit(p.print_help())
    args = p.parse_args()
    return args

# ------------------------------------
# Misc functions
# ------------------------------------

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    # Get parameters
    args=argParser()
    ftype = args.fname.endswith('.tab') and 'tab' or 'bed' 
    fio=FastaFile(args.genome)
    for i,item in enumerate(IO.ColumnReader(args.fname,ftype=ftype)):
        seq=fio.getSeq(item.chrom,item.start,item.stop,item.strand)
        if len(seq)>0:
            print '>'+(item.id!="NONAME" and item.id or "item_"+str(i))
            if args.case=='u':
                seq=seq.upper()
            elif args.case=='l':
                seq=seq.lower()
            if args.linelength:
                seq=Utils.formatSeq(seq,args.linelength)
            print seq
    fio.close()

