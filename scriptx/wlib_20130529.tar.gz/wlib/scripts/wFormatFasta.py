#!/usr/bin/python
#Last-modified: 12 Dec 2012 04:25:14 PM

""" Module/Scripts Description

Copyright (c) 2008 Yunfei Wang <tszn1984@gmail.com>

This code is free software; you can redistribute it and/or modify it
under the terms of the BSD License (see the file COPYING included with
the distribution).

@status:  experimental
@version: 1.0.0
@author:  Yunfei Wang
@contact: tszn1984@gmail.com
"""

# ------------------------------------
# python modules
# ------------------------------------

import sys
import string
from wLib.wBed import Utils,IO

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    if len(sys.argv)==1:
        print "Usage: "+sys.argv[0]+" *.fa [length=100]"
        print "Print fasta sequence with a fixed line length."
    else:
        try:
            length=int(sys.argv[2])
        except:
            length=100
        for fa in IO.SeqReader(sys.argv[1],'fasta'):
            print ">"+fa.id
            print Utils.formatSeq(fa.seq,length)

