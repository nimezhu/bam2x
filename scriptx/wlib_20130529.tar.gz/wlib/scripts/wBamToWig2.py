#!/usr/bin/python
#Last-modified: 28 Nov 2012 11:14:57 AM

""" Module/Scripts Description

Copyright (c) 2008 Yunfei Wang <tszn1984@gmail.com>

This code is free software; you can redistribute it and/or modify it
under the terms of the BSD License (see the file COPYING included with
the distribution).

@status:  experimental
@version: 1.0.0
@author:  Yunfei Wang
@contact: tszn1984@gmail.com
"""

# ------------------------------------
# python modules
# ------------------------------------

import os
import sys
import string
import argparse
import pysam
import numpy
import time

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

def argParser():
    ''' Parse arguments. '''
    p=argparse.ArgumentParser(description='Convert BAM file to Wiggle file in specific binsize.',epilog='dependency pysam')
    p._optionals.title = "Options"
    p.add_argument("-t",dest="treatments",type=str,metavar="chip.bam", required=True, nargs='*',help="The ChIP experiment BAM file(s).")
    p.add_argument("-c",dest="control",type=str,metavar="control",help="The ChIP control BAM file.")
    p.add_argument("-b",dest="binsize",type=int,metavar='binsize',default=50,help="Binsize  used to generate the Wiggle file. [default=50]")
    p.add_argument("-e",dest="extend", type=int,metavar='extend' ,default=150,help="Extend read length by strand. Set 0 if no extension. [default= 150bp]")
    p.add_argument("-n",dest="normedto",type=int,metavar="normedto",default=1000000,help="Reads normalization . Set 0 if no normalization. [default= 1M]")
    p.add_argument("-s",dest="split",action='store_true',default=False,help="Split wiggle into separate files by chromosomes.")
    p.add_argument("-o",dest="outputdir",type=str,metavar="ourputdir",default=".",help="Directory to put wiggle file(s). Default is current directory.")
    if len(sys.argv)==1:
        sys.exit(p.print_help())
    args = p.parse_args()
    return args

def bamToBins(bname,binsize=50,extend=150,normedto=1000000):
    ''' Extend BAM and pileup to bins. '''
    bins={}
    sam=pysam.Samfile(bname,'rb')
    print >>sys.stderr, "BAM->bins ....."
    starttime=time.clock()
    ratio= normedto==0 and 1.0 or float(normedto)/sam.mapped
    for tid,chrlen in enumerate(sam.lengths):
        bins[sam.references[tid]]=numpy.zeros(chrlen/binsize+extend/binsize+1,'float')
    
    # Extension
    cnt=0
    start=stop=0
    for read in sam: # sam is 0-based
        if not read.is_unmapped:
            cnt+=1
            if cnt%10000==0:
                print >>sys.stderr, "Processed ",cnt,"reads.      \r",
            if extend:
                if read.is_reverse:
                    start, stop = max(0,read.pos+read.qlen-extend), read.pos+read.qlen-1
                else:
                    start, stop = read.pos, read.pos+extend-1
            else:
                start, stop = read.pos, read.pos+read.qlen-1
            # Add read to bins
            chrom, startbin, stopbin = sam.references[read.tid], start/binsize, stop/binsize
            # For startbin: 
            # take base pos 6 (1 based) as an example, binsize=50, readlen=60
            # pos 6-50 are in the startbin (50-6%50+1)
            # BAM file are 0 based, so bam.pos=5
            # So the bases in the startbin is binsize-bam.pos%binsize =
            bins[chrom][startbin]-=start%binsize 
            # For stopbin:
            # stop is pos 65 (1 based, 6+60-1). bam.stop is 64 (0 based)
            # pos 51-65  are in the stopbin ((65-1)%50+1=15) Note: it is different from 65%50=15.
            # So the bases in the stopbin is bam.stop%binsize+1 = 64%50+1
            bins[chrom][stopbin] +=stop%binsize+1 
            bins[chrom][startbin:stopbin]+=binsize
    print >>sys.stderr, "Prcessed ",cnt, "reads.     "
    
    
    # Normalization
    print >>sys.stderr, "Normalization ratio=%-3.2f" % ratio
    for chrom in bins:
        bins[chrom]*=float(ratio)/binsize
        if sam.lengths[sam.references.index(chrom)]%binsize: # Set the last incomplete bin to 0
            bins[chrom][-1]=0
    sam.close()

    # time used
    endtime=time.clock()
    print >>sys.stderr, "Time used: %-3.2f secs." % (endtime-starttime)
    return bins

def normalizeBins(treatbins,ctlbins=None):
    ''' Normalize bins against control. '''
    if ctlbins:
        for chrom in treatbins:
            treatbins[chrom]-=ctlbins[chrom]
            treatbins[chrom]+=abs(bins[chrom])
            treatbins[chrom]/=2
    return;

def binsToWig(outputdir,samfile,bins,chrsplit=False):
    ''' Print to wig files. '''
    starttime=time.clock()
    # Get bname prefix
    bname=os.path.basename(samfile)
    bname=outputdir+"/"+os.path.splitext(bname)[0]
    
    # chroms
    chroms=[]
    sam=pysam.Samfile(samfile,'rb')
    for tid,length in enumerate(sam.lengths):
        chroms.append((sam.references[tid],length))
    sam.close()

    # binsize
    binsize=chroms[0][1]/len(bins[chroms[0][0]])+1
    
    # Open wiggle file
    if not chrsplit:
        fh=open(bname+".wig",'w')
        print >>fh, "track type=wiggle_0 name="+os.path.basename(bname)
    
    # Print wiggle
    for chrom in bins:
        print >>sys.stderr, "Bins->Wiggle ", chrom, '  \r',
        
        # Open Wiggle file
        if chrsplit:
            fh=open(bname+"_"+chrom+".wig",'w')
            print >>fh, "track type=wiggle_0 name="+os.path.basename(bname)+"_"+chrom
        
        # Print wiggle lines
        print >>fh, "variableStep chrom="+chrom+" span="+str(binsize)
        for i in numpy.nonzero(bins[chrom]):
            if bins[chrom][i]!=0:
                print >>fh, "%d\t%-3.3f" % (i*binsize+1,bins[chrom][i])
        
        # Close file handle
        if chrsplit:
            fh.close()
    
    # Close file handle
    if not chrsplit:
        fh.close()

    print >>sys.stderr
    endtime=time.clock()
    print >>sys.stderr, "Time used: %-3.2f secs." % (endtime-starttime)
    return

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    # Get parameters
    args=argParser()
    binsize=args.binsize
    extend=args.extend
    normedto=args.normedto
    chromsplit=args.split
    treatments=args.treatments
    outputdir=args.outputdir
    if not os.path.exists(outputdir):
        os.makedirs(outputdir)
    
    # Print parameters
    print >>sys.stderr, "Parameters:"
    print >>sys.stderr, "\tbinsize=", binsize,"bp"
    print >>sys.stderr, extend   and "\textend to %d bp" % extend or "\tNo extension"
    print >>sys.stderr, normedto and "\tnormalized to %d reads" % normedto or "\tNo normalization"
    if chromsplit:
        print >>sys.stderr, "\tSplit wiggle by chromosomes."
    print >>sys.stderr, outputdir=="." and "\toutput in current dir" or "\toutput in "+outputdir
    print >>sys.stderr
    

    # read bigWig
    chroms=wWigIO.getChroms()
    wigs={}
    for chrom in chroms:
        wigs[chrom]=numpy.zeros(chroms[chrom]/binsize)




    # read control
    ctlbins=None
    if args.control:
        print >>sys.stderr, "Reading control:",args.control
        ctlbins=bamToBins(args.control,binsize,extend,normedto)
    
    # read treatment
    for samfile in treatments:
        print >>sys.stderr, "Reading treatment:",samfile
        treatbins=bamToBins(samfile,binsize,extend,normedto)
        # normalize bins
        normalizeBins(treatbins,ctlbins)
        # Wiggle output
        binsToWig(outputdir,samfile,treatbins,binsize,chromsplit)

        


