#!/usr/bin/python
#Last-modified: 17 Dec 2012 05:20:54 PM

""" Module/Scripts Description

Copyright (c) 2008 Yunfei Wang <tszn1984@gmail.com>

This code is free software; you can redistribute it and/or modify it
under the terms of the BSD License (see the file COPYING included with
the distribution).

@status:  experimental
@version: 1.0.0
@author:  Yunfei Wang
@contact: tszn1984@gmail.com
"""

# ------------------------------------
# python modules
# ------------------------------------

import sys
import string
from wLib.wBed import IO,Utils

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    if len(sys.argv)==1:
        print "Usage: "+sys.argv[0]+" id.lst *.fa"
    else:
        with open(sys.argv[1]) as f:
            for faid in f.readlines():
                faid=faid.rstrip("\n")
                seq=IO.getSeq(sys.argv[2],faid)
                print ">"+faid
                print Utils.formatSeq(seq)

