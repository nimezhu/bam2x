#!/usr/bin/python
#Last-modified: 27 Apr 2013 06:39:10 PM

#         Module/Scripts Description
# 
# Copyright (c) 2008 Yunfei Wang <Yunfei.Wang1@utdallas.edu>
# 
# This code is free software; you can redistribute it and/or modify it
# under the terms of the BSD License (see the file COPYING included with
# the distribution).
# 
# @status:  experimental
# @version: 1.0.0
# @author:  Yunfei Wang
# @contact: Yunfei.Wang1@utdallas.edu

# ------------------------------------
# python modules
# ------------------------------------

import sys
import string
from wLib.wBed import IO,Utils

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    if len(sys.argv)==1:
        sys.exit("Example:"+sys.argv[0]+" *.bed hg19 ")
    beds={}
    for chrom in Utils.genomeSize(sys.argv[2]):
        beds[chrom]={}

    for tbed in IO.ColumnReader(sys.argv[1],ftype='bed'):
        if beds[tbed.chrom].has_key(tbed.start):
            beds[tbed.chrom][tbed.start][0]+=";"+tbed.id
        else:
            beds[tbed.chrom][tbed.start]=[tbed.id,tbed.strand]
    for chrom in sorted(beds.keys()):
        for start in sorted(beds[chrom].keys()):
            print "%s\t%d\t%d\t%s\t0\t%s" %( chrom, start,start+1,beds[chrom][start][0],beds[chrom][start][1])

