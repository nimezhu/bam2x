#!/usr/bin/python
#Last-modified: 26 Mar 2013 10:31:19 AM

#         Module/Scripts Description
# 
# Copyright (c) 2008 Yunfei Wang <Yunfei.Wang1@utdallas.edu>
# 
# This code is free software; you can redistribute it and/or modify it
# under the terms of the BSD License (see the file COPYING included with
# the distribution).
# 
# @status:  experimental
# @version: 1.0.0
# @author:  Yunfei Wang
# @contact: Yunfei.Wang1@utdallas.edu

# ------------------------------------
# python modules
# ------------------------------------

import sys
import string
import argparse
from wLib.wBed import IO

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

def argParser():
    ''' Parse arguments. '''
    p=argparse.ArgumentParser(description='Calculate GC content of Fasta file.',epilog='dependency wbed')
    p._optionals.title = "Options"
    p.add_argument("-i","--input",dest='fname',type=str,metavar="input.fa",required=True,help="Fasta file name.")
    if len(sys.argv)==1:
        sys.exit(p.print_help())
    args = p.parse_args()
    return args

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    # Get parameters
    args=argParser()
    tlen=0
    gccnt=0
    for tseq in IO.SeqReader(args.fname):
        tseq.seq=tseq.seq.upper()
        cnt=tseq.seq.count("G")+tseq.seq.count("C")
        length=len(tseq.seq)-tseq.seq.count("N")
        print "%s\t%-3.3f" % (tseq.id, float(cnt)/(length and length or 1))
        gccnt+=cnt
        tlen+=length
    print "Total\t%-3.3f" % (float(gccnt)/(tlen and tlen or 1))

