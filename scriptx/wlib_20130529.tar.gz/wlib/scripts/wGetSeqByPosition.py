#!/usr/bin/python
#Last-modified: 17 Dec 2012 05:22:26 PM

""" Module/Scripts Description

Copyright (c) 2008 Yunfei Wang <tszn1984@gmail.com>

This code is free software; you can redistribute it and/or modify it
under the terms of the BSD License (see the file COPYING included with
the distribution).

@status:  experimental
@version: 1.0.0
@author:  Yunfei Wang
@contact: tszn1984@gmail.com
"""

# ------------------------------------
# python modules
# ------------------------------------

import sys
import string
from wLib.wBed import Utils,IO

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    if len(sys.argv)==1:
        print "Usage: "+sys.argv[0]+" *.fa seqName start stop name strand"
        print "       Coordinates are 1 based."
        print "       start = 1 by default."
        print "       stop = 0 by default. stop=0 means stop is the last base of the sequence."
        print "       name = NONAME by default."
        print "       strand = + by default."
    else:
        fid=sys.argv[2]
        try:
            start=int(sys.argv[3])-1
        except:
            start=0
        try:
            stop=int(sys.argv[4])
            if stop ==0:
                stop=None
        except:
            stop=None
        try:
            name=sys.argv[5]
        except:
            name="NONAME"
        try:
            strand=sys.argv[6]
        except:
            strand="+"
        # read fasta sequence file
        seq=IO.getSeq(sys.argv[1],fid,start,stop,strand)
        print ">"+name
        print Utils.formatSeq(seq)

