#!/usr/bin/python
#Last-modified: 01 Nov 2012 12:09:24 AM

""" Module/Scripts Description

Copyright (c) 2008 Yunfei Wang <tszn1984@gmail.com>

This code is free software; you can redistribute it and/or modify it
under the terms of the BSD License (see the file COPYING included with
the distribution).

@status:  experimental
@version: 1.0.0
@author:  Yunfei Wang
@contact: tszn1984@gmail.com
"""

# ------------------------------------
# python modules
# ------------------------------------

import sys
import string
import argparse
from wLib.wBed import Bed,IO

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

def argParser():
    ''' Parse arguments. '''
    p=argparse.ArgumentParser(description='Extend Bed/GeneBed region to upstream and/or downstream.',epilog='dependency wbed')
    p._optionals.title = "Options"
    p.add_argument("-i","--input",dest='fname',type=str,metavar="Input",required=True,help="Either .bed or .tab file.")
    p.add_argument("-u","--up",dest="up",type=int,metavar="upstream",default=0,help="bps extended to upstream. If minus, trim the 5' end.")
    p.add_argument("-d","--down",dest="down",type=int,metavar="downstream",default=0,help="bps extended to downstream. If minus, trim the 3' end.")
    if len(sys.argv)==1:
        sys.exit(p.print_help())
    args = p.parse_args()
    return args

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    # Get parameters
    args=argParser()
    # Not finished
    for item in IO.ColumnReader(args.fname,ftype= args.fname.endswith(".tab") and "tab" or "bed"):
        print item.updownExtend(args.up,args.down)

