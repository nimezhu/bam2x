#include <stdlib.h>
#include <stdio.h> // for test output
#include <string.h>
#include <Python.h>
#include "common.h"
#include "linefile.h"
#include "hash.h"
#include "options.h"
#include "localmem.h"
#include "udc.h"
#include "bigWig.h"

// struct BigWigFile 
struct BigWigFile
{
	char inFile[255];
	struct bbiFile *bwf;
	struct bbiChromInfo *chromList;
	struct BigWigFile *next;
};

// BigWigList. Save file handels of bigwig files to avoid frequent opening and closing. Allow to open multiple files.
static struct BigWigFile *BigWigList=NULL;

// Cleanup BigWigFile struct
static void BigWigFileCleanup( char *inFile)
{
	// Find position of file
	struct BigWigFile *p,*q;
	p=BigWigList;
	// First node
	if (sameString(inFile,p->inFile)) 
	{
		BigWigList=p->next;
		bbiFileClose(&(p->bwf));
		bbiChromInfoFreeList(&(p->chromList));
		free(p);
		return NULL;
	}
	// Other nodes
	for (;p->next!=NULL;p=p->next)
		if (sameString(inFile,p->next->inFile))
			break;
	// File name not in list
	if (p->next==NULL) return NULL;
	q=p->next;
	p->next=p->next->next;
	bbiFileClose(&(p->bwf));
	bbiChromInfoFreeList(&(p->chromList));
	free(p);
	return NULL;
}

// close wig file 
static   PyObject *closeWig(PyObject *self,PyObject *args)
{
	char *inFile;
	if (BigWigList==NULL) // empty node list
		return Py_BuildValue("");
	if(!PyArg_ParseTuple(args,"s",&inFile)) return Py_BuildValue("");
	BigWigFileCleanup(inFile);
	return Py_BuildValue("");
}

// Build BigWigFile struct
static void BigWigFileBuild( char *inFile)
{
	struct bbiFile *bwf = NULL;
	struct bbiChromInfo *chromList = NULL;
	// see if file exists
	struct BigWigFile *p;
	for(p=BigWigList;p!=NULL;p=p->next)
	{
		if(sameString(inFile,p->inFile))
		{
			BigWigFileCleanup(inFile);
			break;
		}
	}

	// Open bigwig file
	bwf = bigWigFileOpen(inFile);
	chromList = bbiChromList(bwf);
	// Create new BigWigFile node
	struct BigWigFile *cur;
	cur=(struct BigWigFile *)malloc(sizeof(struct BigWigFile));
	strcpy(cur->inFile,inFile);
	cur->bwf=bwf;
	cur->chromList=chromList;
	cur->next=BigWigList; // Add node to top of BigWigList;
	BigWigList=cur;
	return ;
}

// Open bigwig file
static PyObject *openWig(PyObject *self,PyObject *args)
{
	char *inFile;

	if(!PyArg_ParseTuple(args,"s",&inFile)) return Py_BuildValue("");
	BigWigFileBuild(inFile);
	return Py_BuildValue("");
}

static PyObject *getChromSize(PyObject *self,PyObject *args)
{
	char *inFile;
	char *clChrom;
	struct bbiChromInfo *chrom=NULL;
	PyObject *valdict=Py_BuildValue("{}");

	if(!PyArg_ParseTuple(args,"s",&inFile)) return Py_BuildValue("");
	struct BigWigFile *p;
	for(p=BigWigList;p!=NULL;p=p->next) // Find inFile name
		if(sameString(inFile,p->inFile))
		{
			chrom=p->chromList;
			break;
		}
	for(; chrom !=NULL; chrom = chrom->next)
	{
		PyDict_SetItem(valdict, Py_BuildValue("s",chrom->name), Py_BuildValue("i",chrom->size));
	}
	return valdict;
}

// Get intervals from BigWig file. Coordinates are 0 based.
static PyObject *getIntervals(PyObject *self,PyObject *args) 
{
	//Parse the args
	char *inFile, *clChrom;
	int clStart,clEnd;
	if(!PyArg_ParseTuple(args,"ssii",&inFile,&clChrom,&clStart,&clEnd)) return Py_BuildValue("");
	PyObject *intervals=Py_BuildValue("[]");
	struct bbiFile *bwf=NULL;
	struct bbiChromInfo *chrom=NULL;
	struct BigWigFile *p=NULL;

	// Find file name
	for(p=BigWigList;p!=NULL;p=p->next)
	{
		if(sameString(inFile,p->inFile))
		{
			bwf=p->bwf;
			chrom=p->chromList;
			break;
		}
	}
	
	// if not found, open it
	if (bwf==NULL)
	{
		BigWigFileBuild(inFile);
		// The new node is the first node
		bwf=BigWigList->bwf;
		chrom=BigWigList->chromList;
	}

	for (; chrom != NULL; chrom = chrom->next)
	{
		if (clChrom != NULL && !sameString(clChrom, chrom->name))
			continue;
		char *chromName = chrom->name;
		struct lm *lm = lmInit(0);
		int start = 0, end = chrom->size;
		if (clStart > 0)
			start = clStart;
		if (clEnd > 0)
			end = clEnd;
		struct bbiInterval *interval, *intervalList = bigWigIntervalQuery(bwf, chromName, start, end, lm);
		for (interval = intervalList; interval != NULL; interval = interval->next)
		{
			PyObject *rslt = PyTuple_New(3);
			PyTuple_SetItem(rslt, 0, Py_BuildValue("i",interval->start));
			PyTuple_SetItem(rslt, 1, Py_BuildValue("i",interval->end));
			PyTuple_SetItem(rslt, 2, Py_BuildValue("f",interval->val));
			PyList_Append(intervals,rslt);
		}
		lmCleanup(&lm);
	}
	return intervals;
}

static struct PyMethodDef wWigIOMethods[]=
{
		{"close",closeWig,1},
		{"open",openWig,1},
		{"getIntervals",getIntervals,1},
		{"getChromSize",getChromSize,1},
		{NULL,NULL}
};  


void initwWigIO()
{
	    PyObject * m;
		    m=Py_InitModule("wWigIO",wWigIOMethods);
}


