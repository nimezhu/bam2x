#!/usr/bin/python
#Last-modified: 01 Nov 2012 08:46:17 AM

#         Module/Scripts Description
# 
# Copyright (c) 2008 Yunfei Wang <Yunfei.Wang1@utdallas.edu>
# 
# This code is free software; you can redistribute it and/or modify it
# under the terms of the BSD License (see the file COPYING included with
# the distribution).
# 
# @status:  experimental
# @version: 1.0.0
# @author:  Yunfei Wang
# @contact: Yunfei.Wang1@utdallas.edu

# ------------------------------------
# python modules
# ------------------------------------

import sys
import string
from wLib.wBed import IO

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

# ------------------------------------
# Classes
# ------------------------------------

class twoBitIO:
    ''' Manipulate twoBit file. '''
    def __init__(self,fname=None):
        ''' Initiation. '''
        self.fname=None
    def twoBitFile(fname,mtype='rb'):
        
# ------------------------------------
# Main
# ------------------------------------

if __name__=="__main__":
    if len(sys.argv)==1:
        sys.exit("Example:"+sys.argv[0]+"file1 file2... ")
    for item in IO.ColumnReader(sys.argv[1],ftype='bed'):
        print item

