/* zTest - test. */
#include <Python.h>
#include <string.h>
#include "common.h"
#include "linefile.h"
#include "hash.h"
#include "options.h"
#include "dnaseq.h"
#include "fa.h"
#include "twoBit.h"


char *cgetSeq(char *tbfname, char *seqID, 
        int start, int end)
/* Output sequence. */
{
    struct twoBitFile *tbf;
    tbf=twoBitOpen(tbfname);
    struct dnaSeq *seq = twoBitReadSeqFrag(tbf, seqID, start, end);
    /*printf(seq->name);
    printf(seq->dna);*/
    twoBitClose(&tbf);
    return seq->dna;
};
static PyObject *getTwoBitSeqNames(PyObject *self,PyObject *args)
{
    char *tbfname;
    struct slName *s;
    struct twoBitIndex *index;
    PyObject *list=Py_BuildValue("[]");
    struct twoBitFile *tbf;
    if(!PyArg_ParseTuple(args,"s",&tbfname)) return NULL;
    tbf=twoBitOpen(tbfname);
    for (index = tbf->indexList; index != NULL; index = index->next)
    {
        PyObject *name=Py_BuildValue("s",index->name);
        PyList_Append(list,name);
    }
    twoBitClose(&tbf);
    return list;
};

static PyObject *getSeq(PyObject * self, PyObject *args)
{
    char *tbfname,*seqid;
    int start,end;
    char *seq;
    if(!PyArg_ParseTuple(args,"ssii",&tbfname,&seqid,&start,&end)) return NULL;
    seq=cgetSeq(tbfname,seqid,start,end);
    return Py_BuildValue("s",seq);
};
static PyObject *getSeqSizes(PyObject *self, PyObject *args)
{
    char *tbfname;
    struct twoBitFile *tbf;
    struct twoBitIndex *index;
    int size;
    if(!PyArg_ParseTuple(args,"s",&tbfname)) return NULL;
    tbf=twoBitOpen(tbfname);
    PyObject *hash=PyDict_New();
    for (index = tbf->indexList; index != NULL; index = index->next)
    {
        PyObject *name=Py_BuildValue("s",index->name);
        size=twoBitSeqSize(tbf,index->name);
        PyObject *psize=Py_BuildValue("i",size);
        PyDict_SetItem(hash,name,psize);
    }
    twoBitClose(&tbf);
    return hash;
    
}
static struct PyMethodDef zSeqIOMethods[]=
{
    {"getSeq",getSeq,1},
    {"getTwoBitSeqNames",getTwoBitSeqNames,1},
    {"getSeqSizes",getSeqSizes,1},
    {NULL,NULL}
};

void initzSeqIO()
{
    PyObject * m;
    m=Py_InitModule("zSeqIO",zSeqIOMethods);
};



