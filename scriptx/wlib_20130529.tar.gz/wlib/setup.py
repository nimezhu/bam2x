#!/usr/bin/python
#Last-modified: 29 May 2013 04:10:47 PM

#         Module/Scripts Description
# 
# Copyright (c) 2008 Yunfei Wang <Yunfei.Wang1@utdallas.edu>
# 
# This code is free software; you can redistribute it and/or modify it
# under the terms of the BSD License (see the file COPYING included with
# the distribution).
# 
# @status:  experimental
# @version: 1.0.0
# @author:  Yunfei Wang
# @contact: Yunfei.Wang1@utdallas.edu

# ------------------------------------
# python modules
# ------------------------------------

import os,sys
import string
from distutils.core import setup, Extension

# ------------------------------------
# constants
# ------------------------------------

# ------------------------------------
# Misc functions
# ------------------------------------

# ------------------------------------
# Classes
# ------------------------------------

# ------------------------------------
# Main
# ------------------------------------

if __name__ == '__main__':
    if float(sys.version[:3])<2.6 or float(sys.version[:3])>=2.8:
        sys.stderr.write("CRITICAL: Python version must be 2.6 or 2.7!\n")
        sys.exit(1)

    # Python.h path
    # includepy = "%s/include/python%s" % (sys.prefix, sys.version[:3])
    # gcc args: -fPIC includepy are included by default

    # args for wWigIO and zSeqIO
    extra_compile_args = '-w -shared -fPIC -p -IKentLib/inc'.split(' ')
    
    # Compile Kent lib
    print "Compile KentLib ..."
    os.system('cd KentLib && make && cd ..')

    setup(name="wLib",
          version="1.0.0",
          description="Libraries and scripts for seqeuencing data analysis",
          author='Yunfei Wang',
          author_email='Yunfei.Wang1@utdallas.edu',
          url='http://www.utdallas.edu/~Yunfei.Wang1/',
          package_dir={'wLib': 'lib'},
          packages=['wLib'],
          scripts=['bin/wBamToWig.py','bin/wXLSToTXT.py','scripts/wBedExtend.py','scripts/wBedToFasta.py','bin/wSam2Bed.py','bin/wWigPlot.py',
                   'scripts/wBedUpstream.py','scripts/wFindNearestAnnotation.py','scripts/wGetTSS.py',
                   'scripts/wlncRNA.py','scripts/wGTFToTab.py','scripts/wFormatFasta.py','scripts/wTabToBed.py',
                   'scripts/wGetSeqByPosition.py','scripts/wGetSeqByName.py','scripts/wRandomBed.py',
                   'scripts/wFindNearestTwoAnnotation.py','scripts/wFindNearestAnnotation.py',
                   'scripts/wBedAnnotation.py','scripts/wBedGetWig.py','scripts/wGCContent.py','scripts/wGetIntron.py','scripts/wGetExon.py'],
          ext_modules=[Extension('wWigIO',['KentLib/wWigIO/wWigIO.c'],extra_link_args=['-lssl','-lz','-lm','KentLib/lib/x86_64/jkweb.a'],extra_compile_args=extra_compile_args),
                       Extension('zSeqIO',['KentLib/zSeqIO/zSeqIO.c'],extra_link_args=['-lssl','-lz','-lm','KentLib/lib/x86_64/jkweb.a'],extra_compile_args=extra_compile_args)],
          #console=['bin/macs14'],
          #app    =['bin/macs14'],
          classifiers=[
              'Development Status :: 5 - productive',
              'Environment :: Console',
              'Intended Audience :: Developers',
              'License :: OSI Approved :: Artistic License',
              'Operating System :: MacOS :: MacOS X',
              'Operating System :: Microsoft :: Windows',
              'Operating System :: POSIX',
              'Programming Language :: Python',
              ],
          )

