#!/usr/bin/python
#Last-modified: 29 May 2013 05:47:03 PM

### Module/Scripts Description
#
# Copyright (c) 2008 Yunfei Wang <tszn1984@gmail.com>
# 
# This code is free software; you can redistribute it and/or modify it
# under the terms of the BSD License (see the file COPYING included with
# the distribution).
# 
# @status:  experimental
# @version: 1.0.0
# @author:  Yunfei Wang
# @contact: tszn1984@gmail.com
# @modified from: zbed by nimezhu@163.com


# ------------------------------------
# python modules
# ------------------------------------

import os,sys,string,random,cPickle,gzip,copy,numpy
#import wRNA
from math import log,sqrt
from bisect import bisect
import wWigIO
# SAM and Fasta file manipulation
import pysam

# ------------------------------------
# constants
# ------------------------------------

# $HOME
USERHOME=os.path.expanduser('~')

# bins
_numBins   = 37450;
_binLevels = 7;

# bins range in size from 16kb to 512Mb 
# Bin  0          spans 512Mbp,   # Level 1
# Bins 1-8        span 64Mbp,     # Level 2
# Bins 9-72       span 8Mbp,      # Level 3
# Bins 73-584     span 1Mbp       # Level 4
# Bins 585-4680   span 128Kbp     # Level 5
# Bins 4681-37449 span 16Kbp      # Level 6
_binOffsetsExtended = [32678+4096+512+64+8+1, 4096+512+64+8+1, 512+64+8+1, 64+8+1, 8+1, 1, 0]
_binFirstShift = 14;      # How much to shift to get to finest bin. 
_binNextShift  = 3;       # How much to shift to get to next larger bin.

# commonly used genome sizes
genome={}
genome['K12']={"K12":4639675}
genome['CFT073']={'CFT073':5231428}
genome['ce6']={'chrI':15072421,'chrII':15279323,'chrIII':13783681,'chrIV':17493785,'chrM':13794,'chrV':20919568,'chrX':17718854}
genome['sc']={'chr01':230218,'chr02':813184,'chr03':316620,'chr04':1531933,'chr05':576874,'chr06':270161,'chr07':1090940,'chr08':562643,'chr09':439888,'chr10':745751,'chr11':666816,'chr12':1078177,'chr13':924431,'chr14':784333,'chr15':1091291,'chr16':948066,'chrM':85779}
genome['hg19']={'chr1':249250621,'chr2':243199373,'chr3':198022430,'chr4':191154276,'chr5':180915260,'chr6':171115067,'chr7':159138663,'chr8':146364022,'chr9':141213431,'chr10':135534747,'chr11':135006516,'chr12':133851895,'chr13':115169878,'chr14':107349540,'chr15':102531392,'chr16':90354753,'chr17':81195210,'chr18':78077248,'chr20':63025520,'chr19':59128983,'chr22':51304566,'chr21':48129895,'chrX':155270560,'chrY':59373566,'chrM':16571}
genome['mm10']={'chrY': 91744698, 'chrX': 171031299, 'chr13': 120421639, 'chr12': 120129022, 'chr11': 122082543, 'chr10': 130694993, 'chr17': 94987271, 'chr16': 98207768, 'chr15': 104043685, 'chr14': 124902244, 'chr19': 61431566, 'chr18': 90702639, 'chrM': 16299, 'chr7': 145441459, 'chr6': 149736546, 'chr5': 151834684, 'chr4': 156508116, 'chr3': 160039680, 'chr2': 182113224, 'chr1': 195471971, 'chr9': 124595110, 'chr8': 129401213}
genome['mm9']={'chrY': '15902555', 'chrX': '166650296', 'chr13': '120284312', 'chr12': '121257530', 'chr11': '121843856', 'chr10': '129993255', 'chr17': '95272651', 'chr16': '98319150', 'chr15': '103494974', 'chr14': '125194864', 'chr19': '61342430', 'chr18': '90772031', 'chrM': '16299', 'chr7': '152524553', 'chr6': '149517037', 'chr5': '152537259', 'chr4': '155630120', 'chr3': '159599783', 'chr2': '181748087', 'chr1': '197195432', 'chr9': '124076172', 'chr8': '131738871'}

# ------------------------------------
# Misc functions
# ------------------------------------

# ------------------------------------
# Classes
# ------------------------------------


class Bed:
    '''    This class is used to process BED format lines. The default BED format has at least three fields.'''
    def __init__(self,x,description=None):
        '''Initiate the bed from either line or list.'''
        try:
            x=x.rstrip("\n\r").split("\t")
        except:
            if isinstance(x[-1],basestring):
                x[-1].rstrip("\n\r")
        self.chrom=x[0].strip()
        self.start=int(x[1])
        if self.start<0:
            self.start=0
        self.stop=int(x[2])
        try:
            self.id=x[3]
        except:
            self.id=""
        try:
            self.score=float(x[4])
        except:
            self.score=1
        try:
            self.strand=x[5]
        except:
            self.strand="."
        try:
            self.otherfields=x[6:]
        except:
            self.otherfields=[]
        self.description=description
    def __str__(self):
        '''Return the bed in basestring format.'''
        string=self.chrom+"\t"+str(self.start)+"\t"+str(self.stop)+"\t"+str(self.id)+"\t"+("%-5.2f\t"% self.score)+self.strand        
        return string
    def toStr(self,outformat='sci'):
        '''Return the bed in basestring format according to outformat.'''
        string=self.chrom+"\t"+str(self.start)+"\t"+str(self.stop)+"\t"+str(self.id)+"\t"+("%2.2e\t"% self.score)+self.strand
        return string
    def __add__(A,B):
        '''Merge Bed A and B together. Please test isOverlap for bed merge!'''
        if not A and not B: return None
        if not A: return copy.deepcopy(B)   #B+0=B
        if not B: return copy.deepcopy(A)   #A+0=A
        if isinstance(A,basestring) or isinstance(B,basestring): return str(A)+str(B)
        if A.chr==B.chr: #A+B
            start=min(A.start,B.start)
            stop=max(A.stop,B.stop)
            return Bed([A.chrom,start,stop,A.id+","+B.id,(A.score*A.length()+B.score*B.length())/(stop-start),A.strand if A.strand==B.strand else "."]) #score= (lenA*scoreA+lenB*scoreB)/len; if strands are different, result strand is ".".
        return None # A and B are not in the same chromosome.
    def __cmp__(self,other):
        ''' Compare two Beds. '''
        return cmp(self.chrom,other.chrom) or cmp(self.start,other.start) or cmp(self.stop,other.stop) or cmp(other.strand,self.strand) or cmp(self.score,other.score)#'.'<'-'<'+'
    def length(self):
        '''Return the bed range.'''
        return self.stop-self.start
    def rc(self):
        ''' Reverse complementary. '''
        if self.strand=="+":
            self.strand="-"
        elif self.strand=="-":
            self.strand="+"
        return
    def isOverlap(self,B):
        '''Return a bool value of the status of if two bed are overlapped.'''
        if not B: return False
        if(self.chrom != B.chrom) : return False            
        if (self.stop <= B.start) : return False
        if (B.stop <= self.start) : return False
        return True
    def overlapLength(self,B):
        '''Return the overlapped length. >0: overlap; =0: neighbour; <0: -distance; -1000000000: not in the same chromosome.'''
        if not B: return -1000000000
        if self.chrom==B.chrom:
            return self.length()+B.length()-max(self.stop,B.stop)+min(self.start,B.start)
        return -1000000000
    def testBoundary(self,genome=genome['hg19']):
        '''Swap the start and stop position and reverse the strand if start is bigger than stop.'''
        if self.start>self.stop:
            print >>sys.stderr, "start is bigger than stop, swap them and reverse the strand."
            self.stop,self.start=self.start,self.stop
            if self.strand=="+": 
                self.strand="-"
            elif self.strand=="-":
                self.strand="+"
        self.start=max(0,self.start)
        self.stop=min(self.stop,genome[self.chrom])
    def distance(self,B):
        '''Get the distance between two Beds.'''
        return -self.overlapLength(B)
    def getSeq(self,fn=USERHOME+"/Data/hg19/hg19.fa"):
        '''Get sequence from Fasta file'''
        fio=FastaFile(fn)
        seq=fio.getSeq(chrom=self.chrom,start=self.start,stop=self.stop,strand=self.strand)
        fio.close()
        return seq
    def pileup(self,sam):
        ''' pileup Bed from Bam file. '''
        for pcol in sam.pileup(self.chrom,self.start+1,self.stop):
            if self.start< pcol.pos <=self.stop:
                yield (pcol.pos-1,pcol.n)
    def pileupByPos(self,sam,forcestrand=True,normalize=10):
        ''' pileup Bed from Bam file into list. normalize=0 means no normalizaztion. Default normalized to 10M'''
        val=numpy.zeros(self.stop-self.start)
        for pcol in sam.pileup(self.chrom,self.start+1,self.stop):
            if self.start< pcol.pos <=self.stop:
                val[pcol.pos-1-self.start]=pcol.n
        if forcestrand and self.strand=="-":
            val=val[::-1]
        if normalize!=0:
            val*=normalize*1000000./sam.mapped
        return val
    def getWig(self,fn,byPos=False,forcestrand=True):
        '''get interval value from bigWig file.'''
        # List of intervals (start,stop,val)
        wigs=IO.getWig(fn,self.chrom,self.start,self.stop)
        if not byPos:
            return wigs
        vals=numpy.zeros(self.stop-self.start,dtype=float)
        for start,stop,val in wigs:
            vals[(start-self.start):(stop-self.start)]+=val
        if forcestrand and self.strand=="-":
            vals=vals[::-1]
        return vals
    def updownExtend(self,up=0,down=0):
        '''Return the a new Bed with upstream up and downstream down'''
        tbed=copy.deepcopy(self)
        if self.strand=="-":
            tbed.start=max(self.start-down,0)
            tbed.stop=self.stop+up
        else:
            tbed.start=max(self.start-up,0)
            tbed.stop=self.stop+down
        tbed.id+=("_up"+str(up) if up!=0 else "")+("_down"+str(down) if down!=0 else "")
        return tbed
    def upstream(self,up=0):
        '''Return a new Bed for the upstream region.'''
        if self.strand=="-":
            start=self.stop
            stop=self.stop+up
        else:
            start=max(self.start-up,0)
            stop=self.start
        tbed=Bed([self.chrom,start,stop,self.id+"_up"+str(up),self.score,self.strand])
        return tbed
    def downstream(self, down=0):
        '''Return a new Bed for the downstream region.'''
        if self.strand=="-":
            start=max(self.start-down,0)
            stop=self.start
        else:
            start=self.stop
            stop=self.stop+down
        tbed=Bed([self.chrom,start,stop,self.id+"_down"+str(down),self.score,self.strand])
        return tbed
    def stringGraph(self,scale=1):
        '''Illustrate the bed in graph mode.'''
        n=int(self.length()*scale)
        if n==0: n=1
        if self.strand == "+": return ">"*n
        if self.strand == "-": return "<"*n
        return "|"*n
    def setDepth(self,cover):
        '''Add depth for each base.'''
        self.depth=cover
    def strandCmp(self,bed):
        '''Test if the same strand.'''
        if bed.strand == "." or self.strand==".": return "."
        return "+" if self.strand == bed.strand else "-"
    def getBIN(self):
        '''Get the genome BIN.'''
        start=self.start>>_binFirstShift
        stop=(self.stop-1)>>_binFirstShift
        for i in range(_binLevels):
            if start==stop:
                return _binOffsetsExtended[i] + start
            else:
                start >>= _binNextShift
                stop  >>= _binNextShift
        print >>sys.stderr,"Error! Bed range is out of 512M."
    def getTSS(self):
        '''Get TSS.'''
        if self.strand!="-":
            return Bed([self.chrom,self.start,self.start+1,self.id+"_TSS",self.score,self.strand])
        else:
            return Bed([self.chrom,self.stop-1,self.stop,self.id+"_TSS",self.score,self.strand])
    def annoBed(self,annos,annotype='exon'):
        '''Return Annotation of tbed.'''
        annostr=[]
        if annos:
            for i,item in enumerate(annos):
                olen=self.overlapLength(item)
                if olen>0:
                    annostr.append(annotype+"_"+str(i)+":"+str(olen))
        return len(annostr) and ";".join(annostr) or None

class BedCoverage(Bed):
    '''Bed6 format with coverage infomation.'''
    def __init__(self,x,description=None):
        '''Initiation'''
        Bed.__init__(self,x,description)
        if isinstance(self.otherfields[0],str):
            self.depth=[float(i) for i in self.otherfields[0].split(',')]
            self.otherfields=self.otherfields[1:]
        elif isinstance(self.otherfields[0],list):
            self.depth=self.otherfields[0]
            self.otherfields=self.otherfields[1:]
        else:
            self.depth=[self.score for i in xrange(self.length())]

class BedList(list):
    '''List class for hold line objects.'''
    def __init__(self,data=[],description=None):
        '''Initiate data by list class.'''
        list.__init__(self,data)
        self.sorted=0
        self.type='bed'
        self.description=description
        self.fio=None
        self.gsize=None
    def readfile(self,infile):
        '''Read data from file by  ColumnReader.'''
        for item in IO.ColumnReader(infile,ftype=self.type):
            self.append(item)
    def sort(self):
        '''sort BedList.'''
        list.sort(self)
        self.sorted=1
    def bisect(self,item):
        '''Find the nearest item for comparation.'''
        if not self.sorted:
            self.sort()
        n=bisect(self,item)
        if n == len(self):
            return n-1
        if item.distance(self[n-1])<=item.distance(self[n]):
            return n-1
        else:
            return n
    def clear(self):
        '''Clear List.'''
        del self[:]
        self.sorted=0
    def mergeSort(bedfiles): #generator
        '''Merge Beds from multiple files. The Bed in each file should be sorted.'''
        print >>sys.stderr, "Make sure each file input is sorted!"
        if isinstance(bedfiles,str):
            bedfiles=[bedfiles]
        if len(bedfiles)==0:
            print >>sys.stderr, "No bed file names provided...."
        elif len(bedfiles)==1: # for single file
            for tbed in ColumnReader(bedfiles[0],'bed'):
                yield tbed
        else: #for multiple file
            cr=[] #List for iteraters
            bedfiledict={} #record bedfile index for iteration
            beds=BedList()
            for index,bedfile in enumerate(bedfiles):
                bedfiledict[bedfile]=index
                cr.append(Utils.ColumnReader(bedfile,'bed'))
                try:
                    beds.append(cr[index].next())
                    beds[index].description=bedfile #record the source file number for iteration
                except Exception,e:
                    print >>sys.stderr,"Read Bed error!",e
                    raise
            beds.sort()
            while True:
                if len(beds)>0:
                    yield beds[0] # yield the minimum bed
                    try:
                        tbed=cr[bedfiledict[beds[0].description]].next()
                        tbed.description=beds[0].description
                        ts=beds.bisect(tbed)
                        beds.insert(ts,tbed) # insert(pos,item) insert tbed in  the right position
                    except StopIteration:
                        print >>sys.stderr,bedfiles[bedfiledict[beds[0].description]]+" is finished..."
                    del beds[0]                
                else:
                    break
    mergeSort=staticmethod(mergeSort)
    def mergeBeds(bedfiles,forcestrand=False): #generator
        '''Merge Beds from multiple files. The overlapped beds are combined. The Bed in each file should be sorted.'''
        beds=[None,None]
        bedcount=[0,0]
        bedindex={".":0,"+":0,"-":(1 if forcestrand else 0)}
        for tbed in BedList.mergeSort(bedfiles):
            if tbed.isOverlap(beds[bedindex[tbed.strand]]):
                beds[bedindex[tbed.strand]]+=tbed
            else:
                if beds[bedindex[tbed.strand]]:
                    bedcount[bedindex[tbed.strand]]+=1
                    beds[bedindex[tbed.strand]].description=beds[bedindex[tbed.strand]].id
                    beds[bedindex[tbed.strand]].id="Region_"+str(bedcount[bedindex[tbed.strand]])
                    yield beds[bedindex[tbed.strand]]
                beds[bedindex[tbed.strand]]=tbed
        for tbed in beds:
            if tbed:
                bedcount[bedindex[tbed.strand]]+=1
                tbed.description="Region_"+str(bedcount[bedindex[tbed.strand]])
                tbed.id,tbed.description=tbed.description,tbed.id
                yield tbed
        assert "Reach this line."
    mergeBeds=staticmethod(mergeBeds)
            
class GeneBed(Bed):
    '''UCSC GenePred format.'''
    def __init__(self,x,description=None):
        '''Initiate from GeneBed lines. GeneBed names column are not allowed to be numbers.'''
        try:
            self.bin=int(x[0])
            if self.bin<10000:
                x=x[1:]
        except:
            pass
        self.id=x[0]
        self.chrom=x[1]
        self.strand=x[2]
        self.start=int(x[3])
        self.stop=int(x[4])
        self.txstart=int(x[5])
        self.txstop=int(x[6])
        self.exoncount=int(x[7])
        if isinstance(x[8],basestring):
            self.exonstarts=[int(p) for p in x[8].split(",")[0:-1]]
            self.exonstops=[int(p) for p in x[9].split(",")[0:-1]]
        else:
            self.exonstarts=[int(p) for p in x[8]]
            self.exonstops=[int(p) for p in x[9]]                    
        try: # score or 
            self.score=float(x[10])
        except:
            self.score=0.
        try:
            self.proteinID=x[11]
        except:
            self.proteinID=None
        try:
            self.otherFields=x[10:]
        except:
            self.otherFields=None
        self.description=description
    def __str__(self):
        '''Return GeneBed line.'''
        return "%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%s,\t%s," % (self.id,self.chrom,self.strand,self.start,self.stop,self.txstart,self.txstop,self.exoncount,",".join([str(p) for p in self.exonstarts]),",".join([str(p) for p in self.exonstops]))
    def toBed(self):
        '''Transform to Bed format.'''
        return Bed([self.chrom,self.start,self.stop,self.id,self.score,self.strand])
    def getExon(self,i,forcestrand=True):
        '''Get the Bed format of ith exon.'''
        if 0<i<=self.exoncount:
            p = self.exoncount-i if forcestrand and self.strand=="-" else i-1
            return Bed([self.chrom,self.exonstarts[p],self.exonstops[p],self.id+":exon_"+str(i),0,self.strand])
        return None            
    def getIntron(self,i,forcestrand=True):
        '''Get the Bed format of ith intron.'''
        if i>0 and i<self.exoncount:
            if forcestrand and self.strand=="-":
                p = self.exoncount-i
            else:
                p = i
            return Bed([self.chrom,self.exonstops[p-1],self.exonstarts[p],self.id+":intron_"+str(i),0,self.strand])
        return None
    def _getUTRs(self,end='left'):
        '''Get the UTR.'''
        if end=='left': #Get the UTR located in the left end of chromosome
            if self.start==self.txstart: #No UTR
                return None
            utr=copy.deepcopy(self)
            for i in range(self.exoncount):
                if self.txstart<=self.exonstops[i]: #the txStart site locates in (i+1)th exon.
                    break
            utr.exonstarts=utr.exonstarts[0:i+1]
            utr.exonstops=utr.exonstops[0:i+1]
            utr.stop=utr.txstop=utr.exonstops[i]=self.txstart
            utr.txstart=self.start
            utr.exoncount=i+1
            return utr
        else: #get the UTR located in the right end of chromosome
            if self.stop==self.txstop: #No UTR
                return None
            utr=copy.deepcopy(self)
            for i in range(self.exoncount-1,-1,-1):
                if self.txstop>=self.exonstarts[i]:
                    break
            utr.exonstarts=utr.exonstarts[i:self.exoncount]
            utr.exonstops=utr.exonstops[i:self.exoncount]
            utr.start=utr.txstart=utr.exonstarts[0]=self.txstop
            utr.txstop=self.stop
            utr.exoncount=self.exoncount-i
            return utr
    def getUTR5(self):
        '''Get the 5UTR.'''
        if self.strand=='-':
            utr5=self._getUTRs('right')
        else:
            utr5=self._getUTRs('left')
        if utr5:
            utr5.id+=':UTR5'
        return utr5
    def getUTR3(self):
        '''Get the 3'UTR.'''
        if self.strand=='-':
            utr3=self._getUTRs('left')
        else:
            utr3=self._getUTRs('right')
        if utr3:
            utr3.id+=':UTR3'
        return utr3
    def overlapLength(self,B):
        '''Return the overlap length between genebed and bed. Only exons are considered.'''
        l=0
        for exon in self.exons():
            l+=exon.overlapLength(B)
        return l
    def exons(self,forcestrand=True):
        '''Iterate all exons.'''
        for i in range(self.exoncount):
            yield self.getExon(i+1,forcestrand)
    def introns(self,forcestrand=True):
        '''Iterate all introns.'''
        for i in range(1,self.exoncount):
            yield self.getIntron(i,forcestrand)
    def getCDS(self):
        '''Return GeneBed object.'''
        if self.txstart==self.txstop:
            return None
        cds=copy.deepcopy(self)
        for i in range(self.exoncount-1,-1,-1):
            if cds.txstop<=cds.exonstarts[i] or cds.txstart>=cds.exonstops[i]:
                del cds.exonstarts[i]
                del cds.exonstops[i]
            else:
                if cds.txstop<=cds.exonstops[i]:
                    cds.exonstops[i]=cds.txstop
                if cds.txstart>=cds.exonstarts[i]:
                    cds.exonstarts[i]=cds.txstart
        cds.exoncount=len(cds.exonstarts)
        cds.start = cds.txstart
        cds.stop  = cds.txstop
        return cds
    def getcDNALength(self):
        '''Return cdna length.'''
        l=0
        for exon in self.exons():
            l+=exon.length()
        return l
    def getSeq(self,fn=USERHOME+"/Data/hg19/hg19.2bit"):
        '''Get cDNA Sequence.'''
        seq=""
        for i in range(self.exoncount):
            seq+=self.getExon(i+1).getSeq(fn)
        return seq
    def getGeneLength(self):
        '''Return gene length.'''
        return self.stop-self.start+1
    def getWig(self,fn):
        '''Return Wig dictionary.'''
        wigs=[]
        pos=0
        for exon in self.exons(False): # forcestrand=False
            wigs.extend(exon.getWig(fn))
        return wigs

class GeneBedList(BedList): 
    '''A list for Genes.'''
    def __init__(self,data=[],description=None):
        BedList.__init__(self,data,description)
        self.type='gene'
        
class Peak(Bed):
    ''' UCSC broadpeak and narrowpeak format. (See http://genome.ucsc.edu/FAQ/FAQformat.html#format12) '''
    def __init__(self,data,description=None):
        ''' Peak initiation. '''
        Bed.__init__(self,data[0:6])
        try:
            self.signalvalue = float(data[6]) # Measurement of overall (usually, average) enrichment for the region.
        except:
            self.signalvalue = 0
        try:
            self.pvalue = float(data[7])      # Measurement of statistical significance (-log10). Use -1 if no pvalue is assigned.
        except:
            self.pvalue = -1
        try:
            self.qvalue = float(data[8])      # Measurement of statistical significance using false discovery rate (-log10). Use -1 if no qvalue is assigned.
        except:
            self.qvalue = -1
        try:
            self.peak    = int(data[9])       # Point-source called for this peak; 0-based offset from chromStart. Use -1 if no point-source called. 
        except:
            self.peak    = -1            # BroadPeak may not have peak offset.
    def getSummit(self):
        ''' Get summit of the peak. Return middle position if not available.'''
        return self.peak+self.start if self.peak else (self.start+self.stop)/2
    def __str__(self):
        ''' string format of a Peak. '''
        return Bed.__str__(self)+"\t%-.2f\t%-.2f\t%-.2f\t%d" % (self.signalvalue,self.pvalue,self.qvalue,self.peak)

class Fasta:
    '''Fasta format.'''
    def __init__(self,name='',seq='',description='',ftype='fasta'):
        '''Initiate the fasta record.'''
        self.id=name
        self.seq=seq
        self.description=description
        self.ftype=ftype.lower()
    def length(self):
        '''get the length of sequence.'''
        return len(self.seq)
    def __str__(self):
        '''String for output of Fasta.'''
        if self.ftype!='fastq': 
            return ">%s%s\n%s" % (self.id,(' '+self.description or ''),self.seq)
        return "@%s\n%s\n+\n%s" %(self.id,self.seq,self.description)
                          
class BedMap(dict):
    '''Map Beds with chromsomes and BIN values.'''
    def __init__(self,organism='hg19'):
        '''Default genome is hg19.'''
        dict.__init__(self)
        for chro in Utils.genomeSize(organism).keys():
            self[chro]={}
    def findOverlap(self,bed,fraction=0.5,forcestrand=False):
        '''Find overlaps with bed and put into bedlist.
           fraction  <1: fraction is the length of overlap.
           fraction >=1: fraction is the fraction * query length.
        '''
        #bedlist=BedList()
        bedlist=[]
        if fraction>=1:
            minover=fraction # fraction is the length of overlap
        else:
            minover=bed.length()*fraction # fraction is the fraction * query length
        maxover=0
        bestmatch=None
        startBin,stopBin= bed.start >> _binFirstShift, (bed.stop-1) >> _binFirstShift
        for i in range(_binLevels):
            offset = _binOffsetsExtended[i]
            for j in xrange(startBin+offset,stopBin+offset+1):
                for item in self[bed.chr].get(j,[]):
                    overlen=bed.overlapLength(item)
                    if overlen>0:
                        if not forcestrand or (forcestrand and bed.strand==item.strand):
                            bedlist.append(item)
                            if maxover<overlen:
                                maxover=overlen
                                bestmatch=item
            startBin >>= _binNextShift
            stopBin >>= _binNextShift
        return (bestmatch,bedlist)
    def intersectBed(self,bed,fraction=0.5,outputoption=1,forcestrand=False):
        '''Intersect bed with items in BedMap.
           Outputoption=0 : No overlap
           Outputoption=1 : best overlap
           Outputoption= Others : all overlaps
        '''
        #outputoption=0 for No overlap,1 for best overlap and 2 for all overlaps}
        bestmatch=None
        (bestmatch,bedlist)=self.findOverlap(bed,fraction,forcestrand)
        if outputoption==0: #No overlap
            return (True if len(bedlist)==0 else False)
        if outputoption==1: #best overlap
            return bestmatch # if description==None, no overlap found.
        #return all overlaps
        return bedlist
    def loadBedToMap(self,bedlist=None,bedtype='bed'):
        '''Load Bed to BedMap from either Bedlist or ColumnReader handle or bedfile. Load one bedlist once.'''
        if bedlist:
            if isinstance(bedlist,str) or isinstance(bedlist,file):
                bedlist=Utils.ColumnReader(bedlist,ftype=bedtype)
            for bed in bedlist:
                _bin=bed.getBIN()
                self[bed.chr].setdefault(_bin,BedList())
                self[bed.chr][_bin].append(bed)

class FastaFile:
    ''' 
    Fasta file fast reader.
    Usage:
        Open file:
            fio=FastaFile("K12.fa")
        Get Sequence:
            fio.getSeq(chrom="K12",start=100,stop=200,region="K12:100-200",strand="+")
        Close file:
            fio.close()

    Parameters:
        At least one of 'chrom' or 'region' should provided.
        chrom=None: return empty string.
        start=None: start at first position
        stop=None:  stop at the end of record.
        strand: default "+"
    '''

    def __init__(self,fname=USERHOME+"/Data/hg19/hg19.fa"):
        ''' Open Fasta file.'''
        try:
            self.fh=pysam.Fastafile(fname)
        except IOError as e:
            self.fh=None
            print "I/O error({0}): {1}".format(e.errno, e.strerror)
    def getSeq(self,chrom,start=None,stop=None,strand="+"):
        ''' Fetch specific region from Fasta file.'''
        if not self.fh:
            print >>sys.stderr, "Fasta file not provided."
            return None
        seq=self.fh.fetch(reference=chrom,start=start,end=stop)
        if strand=="-":
            seq=Utils.rc(seq)
        return seq
    def close(self):
        ''' Close Fasta file. '''
        if self.fh:
            self.fh.close()
        self.fh=None
    def __del__(self):
        ''' Close file. Avoid memory leaks.'''
        if self.fh:
            self.fh.close()

class BigWigFile:
    '''
    Fast reader of BigWig format file.
    Usage:
        Open file:
            fh=BigWigFile("test.bw",'r')
        Fetch regions:
            wigs=fh.fetch(chrom="chr1",start=100,stop=200)
            for start,stop,depth in wigs:
                #do some thing with wig
                print start,stop,depth
        Close file:
            fh.close()
    
    Parameters:
        chrom=None: return empty list.
        start=None: start at first position.
        stop=None:  stop at the end of chromosome.
    '''
    def __init__(self,fname):
        ''' Open BigWig file. '''
        self.fname=fname
        wWigIO.open(self.fname)
    def getChromSize(self):
        ''' Get chromosome sizes.'''
        chroms=wWigIO.getChromSize(self.fname)
        return chroms
    def fetch(self,**kwargs):
        ''' Fetch intervals in a given region. '''
        if kwargs.has_key('chrom'):
            wigs=wWigIO.getIntervals(self.fname,kwargs['chrom'],kwargs.get('start',0),kwargs.get('stop',0))
            return wigs
        print >>sys.stderr, "ERROR: chromosome not provided."
        return wigs
    def fetchBed(self,tbed,byPos=False,forcestrand=True):
        '''Fetch intervals for Bed.'''
        wigs=wWigIO.getIntervals(self.fname,tbed.chrom,tbed.start,tbed.stop)
        if not byPos:
            return wigs
        # get depth by position, return a numpy array.
        vals = numpy.zeros(tbed.length())
        for start,stop,depth in wigs:
            vals[(start-tbed.start):(stop-tbed.start)]+=depth
        if forcestrand and tbed.strand=="-":
            vals=vals[::-1]
        return vals
    def close(self):
        ''' Close BigWig file. '''
        wWigIO.close(self.fname)
    def __del__(self): 
        ''' Close BigWig file.  Avoid memory leaks.'''
        wWigIO.close(self.fname)

class IO:
    '''File IO.'''
    def getSeq(fname,chrom,start=None,stop=None,strand="+"):
        '''
        Get sequence from fasta file. For retrieving a few sequences only. If retrive many regions in the same file, please use class FastaFile.
        Usage:
            IO.getSeq(fname="K12.fa",chrom="K12",start=100,stop=200,region="K12:100-200",strand="+")
        Parameters:
            fname (required)
            chrom+start+stop = region (either is OK)
            start=None: start at first position
            end=None:  stop at the end of record.
            chrom=None: return empty string.
        '''
        fh=pysam.Fastafile(fname)
        seq=fh.fetch(reference=chrom,start=start,end=stop)
        if strand=="-":
            seq=Utils.rc(seq)
        fh.close()
        return seq
    getSeq=staticmethod(getSeq)
    def getWig(fname,chrom="",start=0,stop=0):
        ''' Read bigWig file. '''
        wWigIO.open(fname)
        # List of intervals like (start,stop,val)
        wigs=wWigIO.getIntervals(fname,chrom,start,stop)
        wWigIO.close(fname)
        return wigs
    getWig=staticmethod(getWig)
    def mopen(filename):
        ''' Open file with common or gzip types. '''
        if filename.endswith(".gz"):
            return gzip.open(handle,"r")
        else:
            return open(filename,'r')
    mopen=staticmethod(mopen)
    def dump(handle,filename=None):
        '''Dump object into hard disk.'''
        if not filename:
            filename="tmp"+str(random.randint(0,99))+".dmp.gz"
        fh=gzip.open(filename,'wb')
        cPickle.dump(handle,fh)
        fh.close()
    dump=staticmethod(dump)
    def load(filename):
        '''Load dumpped object into memory.'''
        fh=gzip.open(filename,'rb')
        th=cPickle.load(fh)
        fh.close()
        return th
    load=staticmethod(load)
    def BAMReader(samfile,toBed=False):
        '''Read SAM lines from SAM/BAM file. Lines could be SAM or Bed object.'''
        ftype='r'
        if samfile.endswith(".bam"):
            ftype='rb'
        sam=pysam.Samfile(samfile,ftype)
        if toBed: # Convert to Bed format
            for item in sam:
                if not item.is_unmapped:
                    yield Bed([sam.getrname(item.tid),item.pos,item.aend,item.qname,item.mapq,item.is_reverse and "-" or "+"])
        else:
            for item in sam:
                if not item.is_unmapped:
                    yield item
        sam.close()
        BAMReader=staticmethod(BAMReader)
    def ColumnReader(infile,**kwargs):
        '''
        Read column files. 
        Usage:
            for line in ColumnReader(filename,sep="\t",ftype='bed',skip=10, mask='#'):
                print line

        Parameters:
        ftype: default(None), Bed, Gene/GeneBed/Tab/GenePred, Bowtie or SOAP. Convert line to specific format.
        sep: character, default("\t"). Lines split by "\t".
        skip: numeric, default 0. Skip first n lines.
        mask: character, default '#'. Mask lines start with '#'.
        '''
        fh=IO.mopen(infile)
        convertors={'bed':Bed,'gene':GeneBed,'tab':GeneBed,'genepred':GeneBed,'bowtie':IO.BowtieToBed,'soap':IO.SOAPToBed}
        # Args paser
        sep=kwargs.get('sep','\t')
        ftype=kwargs.get('ftype',None)
        if ftype:
            ftype=ftype.lower()
            convertor=convertors[ftype]
        skip=int(kwargs.get('skip',0))
        mask=kwargs.get('mask','#')

        # Read lines
        skipped=0
        for lnum,line in enumerate(fh):
            if line[0]!=mask:
                if skip==skipped:
                    x=line.rstrip("\n\r").split("\t")
                    if not ftype:
                        yield x
                    else:
                        yield convertor(x)
                else:
                    skipped+=1
        fh.close()
        return 
    ColumnReader=staticmethod(ColumnReader)
    def SeqReader(infile,filetype='fasta'):
        '''Read sequence files.'''
        filetype=filetype.lower()

        #Read lines
        with open(infile) as fh:
            if filetype=='fasta':
                seq=''
                for line in fh:
                    line=line.rstrip('\n')
                    if line[0]!=">":
                        seq+=line
                    else:
                        if seq!='':
                            yield Fasta(fid,seq,desc,filetype)
                        line=line.split()
                        fid=line[0].lstrip('>')
                        desc= len(line)>1 and ' '.join(line[1:]) or ''
                        seq=''
                if seq!='':
                    yield Fasta(fid,seq,desc,filetype)
                raise StopIteration
            elif filetype=='fastq':
                while True:
                    try:
                        fid=fh.next().rstrip('\n').lstrip('@')
                    except:
                        break
                    seq=fh.next().rstrip('\n')
                    fh.next()
                    desc=lines.next().rstrip('\n')
                    yield Fasta(fid,seq,desc,filetype)
                raise StopIteration
    SeqReader=staticmethod(SeqReader)
    def WigReader(wigfile):
        ''' Iteration of .wig file. '''
        fh=open(wigfile,'r')
        mode=''
        chrom=''
        start=0
        span=0
        step=0
        for line in fh:
            if line.startswith( "variableStep" ):
                header=dict( [ field.split( '=' ) for field in line.split()[1:] ] )
                chrom=header['chrom']
                span=int(header.get('span',1))
                mode="variableStep"
            elif line.startswith( "fixedStep" ):
                header= dict( [ field.split( '=' ) for field in line.split()[1:] ] )
                chrom = header['chrom']
                start = int( header['start'] ) - 1
                step  = int( header['step']) - 1
                span=int(header.get('span',1))
                mode = "fixedStep"
            elif mode == "variableStep":
                fields=line.split("\t")
                start=int(fields[0])-1
                yield chrom,start,start+span,float(fields[1])
            elif mode == "fixedStep":
                yield chrom,start,start+span,float(line)
                start+=step
            elif line.startswith( "track" ) or line.startswith( "#" ) or line.startswith( "browser" ):
                continue
            else:
                raise "Unexpected input line: %s" % line.strip()
        fh.close()
    WigReader=staticmethod(WigReader)
    def GFFReader(filename): # obesoleted
        '''Read GFF format file and transform to GeneBed format.'''
        chroTab={'I':'chrI','II':'chrII','III':'chrIII','IV':'chrIV','MtDNA':'chrM','V':'chrV','X':'chrX'}
        gchr=None
        for line in ColumnReader(open(filename)):
            order=line[8][0:2]
            name=line[8].split(';')[0].split(':')[1]
            if order=='ID':
                if gchr:
                    gexons.sort()
                    if gtxstart-1 in gexons:
                        cur=gexons.index(gtxstart)
                        del gexons[cur]
                        del gexons[cur-1]
                    if gtxstop+1 in gexons:
                        cur=gexons.index(gtxstop+1)
                        del gexons[cur]
                        del gexons[cur-1]
                    exonstarts=[]
                    exonstops=[]
                    exoncount=len(gexons)/2
                    for i in range(exoncount):
                        exonstarts.append(gexons[2*i]-1)
                        exonstops.append(gexons[i*2+1])
                    yield GeneBed([gname,gchr,gstrand,gstart-1,gstop,gtxstart-1,gtxstop,exoncount,exonstarts,exonstops])
                #Initiate new record
                gchr=chroTab[line[0]]
                gname=name
                gstrand=line[6]
                gstart=int(line[3])
                gstop=int(line[4])
                gtxstart=gstop
                gtxstop=gstart
                gexons=[]
            elif order=='Pa':
                start=int(line[3])
                stop=int(line[4])
                gexons.append(start)
                gexons.append(stop)
                if line[2]=='coding_exon':
                    gtxstart=min(gtxstart,start)
                    gtxstop=max(gtxstop,stop)
        gexons.sort()
        if gtxstart-1 in gexons:
            cur=gexons.index(gtxstart)
            del gexons[cur]
            del gexons[cur-1]
        if gtxstop+1 in gexons:
            cur=gexons.index(gtxstop+1)
            del gexons[cur]
            del gexons[cur-1]
        exonstarts=[]
        exonstops=[]
        exoncount=len(gexons)/2
        for i in range(exoncount):
            exonstarts.append(gexons[2*i]-1)
            exonstops.append(gexons[i*2+1])
        yield GeneBed([gname,gchr,gstrand,gstart-1,gstop,gtxstart-1,gtxstop,exoncount,exonstarts,exonstops])
    GFFReader=staticmethod(GFFReader)
    def BowtieToBed(x):
        '''Bowtie map result to Bed.Bowtie is 0 based.'''
        x[3]=int(x[3])
        return Bed([x[2],x[3],x[3]+len(x[4]),x[0],1,x[1]])
    BowtieToBed=staticmethod(BowtieToBed)
    def SOAPToBed(x):
        '''SOAP map result to Bed. SOAP is 1 based.'''
        x[8]=int(x[8])-1
        return Bed([x[7],x[8],x[8]+int(x[5]),x[0],1,x[6]])
    SOAPToBed=staticmethod(SOAPToBed)

class BinIO:
    ''' Binary file IO.'''
    def __init__(self,header=None,data=None):
        ''' BinIO initiation. '''
        self.header=header
        self.data=data
    def packheader(self,header=None):
        ''' pack Header'''
        if header!=None:
            self.header=header
        theader='\t'.join([str(h) for h in header])


class Utils:
    def rc(seq):
        ''' Reverse complementary sequence. '''
        comps = {'A':"T", 'C':"G", 'G':"C", 'T':"A",
                'B':"V", 'D':"H", 'H':"D", 'K':"M",
                'M':"K", 'R':"Y", 'V':"B", 'Y':"R",
                'W':'W', 'N':'N', 'S':'S'}
        return ''.join([comps[x] for x in seq.upper()[::-1]])
    rc=staticmethod(rc)
    def MW(seq):
        ''' Molecular weight of sequence. '''
        mws={'A':313.21,'C':289.19,'G':329.21,'T':304.2,'I':314.2,'N':308.95,'R':321.21,'Y':296.69,'M':301.2,'K':316.7,'S':309.2,'W':308.71,'H':302.2,'B':307.53,'D':315.54,'V':310.53,'p':79.98,'X':0,'U':290.17}
        return sum([mws[x] for x in seq.upper()])
    MW=staticmethod(MW)
    def TM(seq,Na=100):
        ''' TM value of sequence. '''
        seq=seq.upper()
        if len(seq)<25:
            tm={'A':2,'T':2,'C':4,'G':4}
            return sum([tm[x] for x in seq])
        else:
            N=float(len(seq))
            gc=(seq.count('C')+seq.count('G'))/N
            return 81.5+16.6*log(Na/1000.0,10)+0.41*gc+600.0/N
    TM=staticmethod(TM)
    def GCContent(seq):
        '''Return GC content of sequence.'''
        tseq=seq.upper()
        gc=(tseq.count("G")+tseq.count("C"))/float(len(tseq)-tseq.count("N"))
        return gc 
    GCContent=staticmethod(GCContent)    
    def toRNA(seq):
        return seq.upper().replace('T','U')
    toRNA=staticmethod(toRNA)
    def toDNA(seq):
        return seq.upper().replace('U','T')
    toDNA=staticmethod(toDNA)
    def toProtein(seq,table):
        '''Translate DNA or RNA to protein according to standard translation table.'''
        seq=seq.upper().rstrip()
        if "U" in seq:
            seq=toDNA(seq)
        if len(seq)%3!=0:
            print >>sys.stderr, "Sequcence length should be 3*N."
            return None
        p=""
        for i in xrange(len(seq)/3):
            p+=table[seq[i*3:(i+1)*3]]
        return p
    toProtein=staticmethod(toProtein)
    def formatSeq(seq,length=100):
        ''' print sequence with fixed length.'''
        l=len(seq)
        n=l/length
        lstr=""
        for i in xrange(n):
            lstr+=seq[(i*length):(i*length+length)]+"\n"
        if l%length:
            lstr+=seq[(n*length):]
        return lstr.rstrip("\n")
    formatSeq=staticmethod(formatSeq)
    def fastaToCSFasta(seq,starter='T'):
        trans= [ ['0','1','2','3'], ['1','0','3','2'], ['2','3','0','1'], ['3','2','1','0']]
        bases= {'A':0,'C':1,'G':2,'T':3}
        csf=starter
        seq=seq.upper()
        tseq=starter+seq
        for i in range(len(seq)):
            csf+=trans[bases[tseq[i]]][bases[tseq[i+1]]]
        return csf
    fastaToCSFasta=staticmethod(fastaToCSFasta)
    def csFastaToFasta(seq):
        trans=[ [0,1,2,3], [1,0,3,2], [2,3,0,1], [3,2,1,0]]
        bases={'A':0,'C':1,'G':2,'T':3}
        csbases={0:'A',1:'C',2:'G',3:'T'}
        f=seq[0]
        for i in range(len(seq)-1):
            f+=csbases[trans[bases[f[i]]][int(seq[i+1])]]
        return f[1:]
    csFastaToFasta=staticmethod(csFastaToFasta)
    def genomeSize(gversion='hg19'):
        '''
        Genome size dictionary. It could be either well known genome names (hg19,ce6,K12,sc) or genome size file with each line like this: chrom\tlength.
        '''
        gv=gversion.split(".")[0]
        if genome.has_key(gv):
            return genome[gv]
        genome[gversion]={}
        try:
            for line in IO.ColumnReader(gversion):
                genome[gversion][line[0]]=int(line[1])
        except:
            print >>sys.stderr, 'Genome size are not available.'
        return genome[gversion]
    genomeSize=staticmethod(genomeSize)
    def getBigWigChroms(bigwigfile):
        ''' Get chrom list from BigWig file.'''
        wWigIO.open(bigwigfile)
        chroms=wWigIO.getChromSize()
        wWigIO.close()
        return chroms
    getBigWigChroms=staticmethod(getBigWigChroms)
    def chromConventor(chrom,_from,_to):
        ''' Convent chromsomes from one type to another.\n Types are 'roman':roman numbers, 'num':numbers, 'fnum': formated numbers, 01,02   '''
        romans=["chrI","chrII","chrIII","chrIV","chrV","chrVI","chrVII","chrVIII","chrIX","chrX","chrXI","chrXII","chrXIII","chrXIV","chrXV","chrXVI","chrXVII","chrXVIII","chrXIX","chrXX","chrXXI","chrXXII"]
        nums=["chr1","chr2","chr3","chr4","chr5","chr6","chr7","chr8","chr9","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19","chr20","chr21","chr22"]
        fnums=["chr01","chr02","chr03","chr04","chr05","chr06","chr07","chr08","chr09","chr10","chr11","chr12","chr13","chr14","chr15","chr16","chr17","chr18","chr19","chr20","chr21","chr22"]
        types={'roman':romans,'num':nums,'fnum':fnums}
        chroms={'roman':{},'num':{},'fnum':{}}
        for i in range(22):
            chroms['roman'][romans[i]]=i
            chroms['num'][nums[i]]=i
            chroms['fnum'][fnums[i]]=i
        idx=chroms[_from].get(chrom,-1)
        if idx!=-1:
            return types[_to][idx]
        else:
            return chrom
    chromConventor=staticmethod(chromConventor)
    def translateTables(tabletype="standard"):
        '''Translation tables. @ for stop condons.'''
        tables={}
        tables["standard"]={
            'TTT': 'F', 'TTC': 'F', 'TTA': 'L', 'TTG': 'L', 'TCT': 'S',
            'TCC': 'S', 'TCA': 'S', 'TCG': 'S', 'TAT': 'Y', 'TAC': 'Y',
            'TGT': 'C', 'TGC': 'C', 'TGG': 'W', 'CTT': 'L', 'CTC': 'L',
            'CTA': 'L', 'CTG': 'L', 'CCT': 'P', 'CCC': 'P', 'CCA': 'P',
            'CCG': 'P', 'CAT': 'H', 'CAC': 'H', 'CAA': 'Q', 'CAG': 'Q',
            'CGT': 'R', 'CGC': 'R', 'CGA': 'R', 'CGG': 'R', 'ATT': 'I',
            'ATC': 'I', 'ATA': 'I', 'ATG': 'M', 'ACT': 'T', 'ACC': 'T',
            'ACA': 'T', 'ACG': 'T', 'AAT': 'N', 'AAC': 'N', 'AAA': 'K',
            'AAG': 'K', 'AGT': 'S', 'AGC': 'S', 'AGA': 'R', 'AGG': 'R',
            'GTT': 'V', 'GTC': 'V', 'GTA': 'V', 'GTG': 'V', 'GCT': 'A',
            'GCC': 'A', 'GCA': 'A', 'GCG': 'A', 'GAT': 'D', 'GAC': 'D',
            'GAA': 'E', 'GAG': 'E', 'GGT': 'G', 'GGC': 'G', 'GGA': 'G',
            'GGG': 'G', 'TAA': '@', 'TAG': '@', 'TGA': '@'}
        return tables[tabletype]
    translateTables=staticmethod(translateTables)
    def RESite(re):
        ''' Return the Restriction Enzyme cutting sequence.'''
        REs={'HindIII':'AAGCTT','EcoRI':'GAATTC'} # Add more if needed
        return REs.getdefault(re,'')
    RESequence=staticmethod(RESite)


