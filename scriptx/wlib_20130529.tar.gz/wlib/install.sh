#!/bin/sh
#Last-modified: 23 Apr 2013 01:21:40 PM

####################### Module/Scripts Description ######################
#  
#  Copyright (c) 2008 Yunfei Wang <tszn1984@gmail.com>
#  
#  This code is free software; you can redistribute it and/or modify it
#  under the terms of the BSD License (see the file COPYING included with
#  the distribution).
#  
#  @status:  experimental
#  @version: 1.0.0
#  @author:  Yunfei Wang
#  @contact: tszn1984@gmail.com
#
#########################################################################


USAGE=" Usage: $0 ......"
case $# in
	0) echo $USAGE
	   exit;;
	*) ;;
esac

python setup.py install --prefix=$HOME/progs/pylib/
